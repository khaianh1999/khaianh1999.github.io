function resetForm() {
  const idValue = document.getElementById("id");
  const loaiVe = document.getElementById("loaiVe");
  const giaVe = document.getElementById("giaVe");
  const viTri = document.getElementById("viTri");
  const anhCheckin = document.getElementById("anhCheckin");

  idValue.value = "";
  loaiVe.value = "";
  giaVe.value = "";
  viTri.value = "";
  anhCheckin.value = "";
}

function validateForm(ticket) {
  // TODO: make do it
  // check validate null, undefined, "", type
  // return true or false
}

function submit() {
  const tickets = JSON.parse(localStorage.getItem("tickets")) || [];

  const idValue = document.getElementById("id");
  const loaiVe = document.getElementById("loaiVe");
  const giaVe = document.getElementById("giaVe");
  const viTri = document.getElementById("viTri");
  const anhCheckin = document.getElementById("anhCheckin");

  if (idValue.value) {
    // update
    tickets.map((ticket) => {
      if (ticket.id === Number(idValue.value)) {
        ticket.loaiVe = loaiVe.value;
        ticket.giaVe = giaVe.value;
        ticket.viTri = viTri.value;
        ticket.anhCheckin = anhCheckin.value;
      }
    });

    localStorage.setItem("tickets", JSON.stringify(tickets));

    resetForm();

    const btnSubmit = document.getElementById("onSubmit");

    btnSubmit.innerText = "Tạo vé";

    render(tickets);
  } else {
    const ticket = {
      id: new Date().getTime(), // timestamps
      loaiVe: loaiVe.value,
      giaVe: giaVe.value,
      viTri: viTri.value,
      anhCheckin: anhCheckin.value,
    };
    // TODO: validate form
    // const isValid = validateForm(ticket);

    // if (!isValid) return false;

    tickets.push(ticket);

    localStorage.setItem("tickets", JSON.stringify(tickets));
    resetForm();

    // window.location.reload();
    render(tickets);
  }
}

function render(tickets) {
  const ticketsTableBodyTag = document.querySelector("#ticketsTable tbody");

  // remove old data in tbody tag
  ticketsTableBodyTag.innerHTML = "";

  for (let i = 0; i < tickets.length; i++) {
    const trNode = document.createElement("tr");
    trNode.style.minHeight = "100px";

    const tdNodeId = document.createElement("td");
    tdNodeId.innerText = tickets[i].id;
    trNode.appendChild(tdNodeId);

    const tdNodeLoaiVe = document.createElement("td");
    tdNodeLoaiVe.innerText = tickets[i].loaiVe;
    trNode.appendChild(tdNodeLoaiVe);

    const tdNodeGiave = document.createElement("td");
    tdNodeGiave.innerText = tickets[i].giaVe;
    trNode.appendChild(tdNodeGiave);

    console.log(trNode)
    for (let j = 0; j < trNode.length; j++) {
     var cells = trNode[j].getElementsByTagName('td');
      console(cells)
    }

    const tdNodeViTri = document.createElement("td");
    tdNodeViTri.innerText = tickets[i].viTri;
    trNode.appendChild(tdNodeViTri);

    const tdNodeAnhCheckin = document.createElement("td");
    const tdNodeAnhCheckinImgInnerTd = document.createElement("img");
    tdNodeAnhCheckinImgInnerTd.src = tickets[i].anhCheckin;
    tdNodeAnhCheckinImgInnerTd.style.width = "150px";
    tdNodeAnhCheckin.appendChild(tdNodeAnhCheckinImgInnerTd);
    trNode.appendChild(tdNodeAnhCheckin);

    const tdNodeHanhDong = document.createElement("td");
    const btnNodeUpdate = document.createElement("button");
    btnNodeUpdate.innerText = "Sửa";
    btnNodeUpdate.setAttribute("data-id", tickets[i].id);
    btnNodeUpdate.setAttribute("data-action", "update");
    btnNodeUpdate.className = "action";
    const btnNodeDelete = document.createElement("button");
    btnNodeDelete.innerText = "Xóa";
    btnNodeDelete.setAttribute("data-id", tickets[i].id);
    btnNodeDelete.setAttribute("data-action", "delete");
    btnNodeDelete.className = "action";

    tdNodeHanhDong.appendChild(btnNodeUpdate);
    tdNodeHanhDong.appendChild(btnNodeDelete);
    trNode.appendChild(tdNodeHanhDong);

    ticketsTableBodyTag.appendChild(trNode);

     //total revenue
   const total_revenue =document.getElementById('total_revenue')
   const rows = document.querySelectorAll('tr')
   var tong=0;
   for(let i =1;i<rows.length;i++){
     var totals = rows[i].querySelectorAll('td')[2];
     tong+=Number.parseInt(totals.innerHTML)
   }total_revenue.innerHTML='$'+tong
 
   //sold today
   const sold_today = document.getElementById('sold_today')
   var a=0;
   for(let i =1;i<rows.length;i++){
     a=a+1;
   }sold_today.innerHTML=a
  }
  

  // add listener event - click
  const btnList = document.querySelectorAll(".action");

  for (let i = 0; i < btnList.length; i++) {
    btnList[i].addEventListener("click", function (event) {
      event.preventDefault();

      switch (btnList[i].getAttribute("data-action")) {
        case "update":
          showTicketToForm(btnList[i].getAttribute("data-id"));
          break;
        case "delete":
          remove(btnList[i].getAttribute("data-id"));
          break;
      }
    });
  }
}

function showTicketToForm(id) {
  // get info from id in array data
  const tickets = JSON.parse(localStorage.getItem("tickets")) || [];

  const ticket = tickets.find((ticket) => ticket.id === Number(id));

  // append info to form
  const idValue = document.getElementById("id");
  const loaiVe = document.getElementById("loaiVe");
  const giaVe = document.getElementById("giaVe");
  const viTri = document.getElementById("viTri");
  const anhCheckin = document.getElementById("anhCheckin");

  idValue.value = ticket.id;
  loaiVe.value = ticket.loaiVe;
  giaVe.value = ticket.giaVe;
  viTri.value = ticket.viTri;
  anhCheckin.value = ticket.anhCheckin;

  const btnSubmit = document.getElementById("onSubmit");

  btnSubmit.innerText = "Sửa vé";
}

function remove(id) {

  // get tickets from localstorage
  const tickets = JSON.parse(localStorage.getItem("tickets")) || [];

  const ticket = tickets.find((ticket) => ticket.id === Number(id));

  // delete item which has id, splice()
  tickets.splice(tickets.indexOf(ticket), 1);
  // set new tickets to localstorage
  localStorage.setItem("tickets", JSON.stringify(tickets));
  // run again render()
  render(tickets);
}

function search(keyword) {
  const tickets = JSON.parse(localStorage.getItem("tickets")) || [];

  newTickets = tickets.filter((ticket) =>
    ticket.loaiVe.toLowerCase().includes(keyword.toLowerCase())
  );

  render(newTickets);
}

function showAndHidden(checkedList) {}

window.addEventListener("DOMContentLoaded", () => {
  // lay tat ca element can lay
  const btnSubmit = document.getElementById("onSubmit");
  const btnSearch = document.querySelector("#onSearch");
  const inputSearch = document.querySelector("#search");

  const tickets = JSON.parse(localStorage.getItem("tickets")) || [];

  render(tickets);

  btnSubmit.onclick = function (e) {
    e.preventDefault();
    submit();
    // localStorage (bộ nhớ thuộc về trình duyệt) - SSD/HHD (key - value: string)
    // sessionStorage (bộ nhớ của phiên trình duyệt) - RAM
  };

  btnSearch.onclick = function (e) {
    e.preventDefault();
    const textSearch = document.querySelector("#search");
    search(textSearch.value);
  };

  inputSearch.onkeypress = function (e) {
    if (e.keyCode === 13 && e.key === "Enter") {
      search(inputSearch.value);
      return false;
    }
  };

 


  // handle sort when click header column
  const headerCell = document.querySelectorAll("#ticketsTable thead th");
  if (typeof headerCell === "array" && headerCell.length > 5) headerCell.pop(); // remove last items which is action column

  for (let i = 0; i < headerCell.length; i++) {
    headerCell[i].addEventListener("click", function (e) {
      e.preventDefault();

      const keyHeaderClicked = headerCell[i].getAttribute("data-prop");
      const keyHeaderClickedTypeOf = typeof tickets[0][keyHeaderClicked];

      // use sort function to sort again data in table
      const tcks = JSON.parse(localStorage.getItem("tickets")) || [];

      if (
        headerCell[i].getAttribute("data-sort") === "0" ||
        headerCell[i].getAttribute("data-sort") === "2"
      ) {
        tcks.sort(function (a, b) {
          if (a[keyHeaderClicked] < b[keyHeaderClicked]) {
            return -1;
          }
          if (a[keyHeaderClicked] > b[keyHeaderClicked]) {
            return 1;
          }
          return 0;
        });

        // TODO: Perform code in here...

        headerCell[i].setAttribute("data-sort", "1"); // Z-A
      } else if (headerCell[i].getAttribute("data-sort") === "1") {
        tcks.sort(function (a, b) {
          if (a[keyHeaderClicked] < b[keyHeaderClicked]) {
            return -1;
          }
          if (a[keyHeaderClicked] > b[keyHeaderClicked]) {
            return 1;
          }
          return 0;
        });

        tcks.reverse();
        headerCell[i].setAttribute("data-sort", "2"); // Z-A
      }

      render(tcks);

      // render again
    });
  }
  
});

// show data into form (created)
// user edit data
// user submit new data
// find index of data which need
// assign new value for record
// set localstorage (again)
// render()

/////// MIND SET
// 1. Edit again render function() add "data-prop" for record in tbody
// 2. if checked, querySlectorAll('*[data-prop="viTri"]')
// 3. style for column
//// 3.1 style display: none / width: 0
//// 3.2 (not recommend): save all column to localstorage, get again if selected/checked ==> append to index of list td(tbody) th(thead)
